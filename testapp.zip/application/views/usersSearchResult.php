<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
                 
<table cellpadding="0" cellspacing="0" border="0" class="datatable table table-striped table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Name</th>
							<th>Email-ID</th>
							<th>Details</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						if(count($userData)>0) {
						$srno = $page + 1;
						foreach($userData as $values) {
						?>
						<tr>
							<td><?php echo $srno; ?></td>
							<td><?php echo $values['name']; ?> </td>
							<td><?php echo $values['email_id']; ?></td>
							<td class="center"><?php echo $values['details']; ?></td>
							
							<td class="center">
								<a href="#">Edit</a> | 
								<a href="<?php echo base_url(); ?>users/userDelete/<?php echo $values['id']; ?>"  onclick="return confirm('Are you sure want to delete selected user?');">Delete</a>
							</td>
							
						</tr>
						<?php 
					$srno++;
					}
				} else {
				?>
				<tr><td colspan="5">Records not found</td></tr>
				<?php
				}
						?>
					</tbody>
</table>
 <ul class="pagination pull-right">
                                <?php
                                echo $links;
                                ?>
                            </ul>
                            
 </div>                          



<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>User Lists</h2>
<!--
<div align=center><pre style="line-height:60%;font-family:Courier New"> --> <?php
/*
$size=13;
for($r=1;$r<($size+1);$r++){
	for($c=1;$c<($r+1);$c++){
		if($r == 13) {
				echo '*';
			} else {
		if($c==1) {
			echo '*';
		} elseif($c == $r) {
			echo '*';
		} else {
			echo ' ';
		}
	
	
	}
	}
	
	echo '<br />';

}
echo ' ';
?></pre></div>

<?php
/*
foreach (range('A', 'Z') as $char) {
    echo $char . "\n";
}
*/
/*
$alphaCharString = '';
foreach (range('a', 'z') as $char) {
    $alphaCharString .= $char ;
}
define ('STR',$alphaCharString);

function generateName($len = 4) {
	 $alphaCharString = STR;
	 $randstring = '';
	for ($i=0; $i<$len; $i++) {
		 $randstring .= @$alphaCharString[rand(0, strlen($alphaCharString))];
	}
	return $randstring;
}

for($x=0; $x<100; $x++) {
	
	echo "<br>".generateName(7);
	
 }*/
 ?>

 <header class="main-box-header clearfix">
                            <div class="filter-block pull-right">
                                <div class="form-inline pull-left">
                                    <form method="POST" action="<?php echo base_url(); ?>users/userlist" id="frmSearch" name="frmSearch">
                                        <input type="search"  placeholder="Search..." class="form-control" id="usersearch" name="usersearch" value="<?php echo !empty($usersearch) ? $usersearch : ''; ?>">
                                        <input type="hidden" name="searchData" value="search"/>
                                        <a onclick="js_search_list();" href="JavaScript:void(0);" class="btn btn-primary">SEARCH</a>
                                        <a href="<?php echo base_url(); ?>users/adduser" class="btn btn-primary">Add New User</a>

                                    </form>
                                </div>
                            </div>

                        </header>
<div  id="searchResult">                       
<table cellpadding="0" cellspacing="0" border="0" class="datatable table table-striped table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Name</th>
							<th>Email-ID</th>
							<th>Details</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						if(count($userData)>0) {
						$srno = $page + 1;
						foreach($userData as $values) {
						?>
						<tr>
							<td><?php echo $srno; ?></td>
							<td><?php echo $values['name']; ?> </td>
							<td><?php echo $values['email_id']; ?></td>
							<td class="center"><?php echo $values['details']; ?></td>
							
							<td class="center">
								<a href="#">Edit</a> | 
								<a href="<?php echo base_url(); ?>users/userDelete/<?php echo $values['id']; ?>"  onclick="return confirm('Are you sure want to delete selected user?');">Delete</a>
							</td>
							
						</tr>
						<?php 
					$srno++;
					}
				} else {
				?>
				<tr><td colspan="5">Records not found</td></tr>
				<?php
				}
						?>
					</tbody>
</table>
 <ul class="pagination pull-right">
                                <?php
                                echo $links;
                                ?>
                            </ul>
                            
 </div>                          
</div>

</body>
</html>
<script>
function js_search_list() {
        
        $.ajax( { type : 'POST',
			data : {'usersearch':$('#usersearch').val(), 'searchData': 'search'},
          url  : '<?php echo base_url(); ?>users/searchresult',              // <=== CALL THE PHP FUNCTION HERE.
          success: function ( data ) {
            var json_obj = JSON.stringify(data);
             var str ='';
             var srno = 1;
             //alert(data);
            /*  $.each(data, function(index, item) {
				  
				str += "<tr><td>"+srno+"</td><td>"+item.name+"</td><td>"+item.email_id+"</td><td>"+item.details+"</td><td><a href='Javascript:void(0);' onclick='edit()'>Edit</a> | <a href='Javascript:void(0);' onclick='jsdelete("+item.id+")'>Delete</a></td></tr>";
				srno++;
        }); */
			$("#searchResult").html(data);
          },
          error: function ( xhr ) {
            alert( "error" );
          }
        });
        
    }
    $("#clearsearch").click(function(){
        $("#usersearch").val();
        var formData = new FormData($("#usersearch"));
        formData.append("usersearch","");
        document.getElementById("frmSearch").submit();
    });

</script>


<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>User Lists</h2>

 <header class="main-box-header clearfix">
                            <div class="filter-block pull-right">
                                <div class="form-inline pull-left">
                                    <form method="POST" action="<?php echo base_url(); ?>users/userlist" id="frmSearch" name="frmSearch">
                                        <input type="search"  placeholder="Search..." class="form-control" id="usersearch" name="usersearch" value="<?php echo !empty($usersearch) ? $usersearch : ''; ?>">
                                        <input type="hidden" name="searchData" value="search"/>
                                        <a onclick="js_search_list();" href="JavaScript:void(0);" class="btn btn-primary">SEARCH</a>
                                                                            <a href="<?php echo base_url(); ?>users/adduser" class="btn btn-primary">Add New User</a>

                                    </form>
                                </div>
                            </div>

                        </header>
                        
<table cellpadding="0" cellspacing="0" border="0" class="datatable table table-striped table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Name</th>
							<th>Email-ID</th>
							<th>Details</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody id="resultDisplay">
						
					</tbody>
</table>
 
</div>

</body>
</html>
<script>
	
	function userList() {
	$.ajax( { type : 'POST',
          url  : 'http://localhost/codeIgniter-3-api/test/getUsersList',              // <=== CALL THE PHP FUNCTION HERE.
          success: function ( data ) {
            var json_obj = JSON.stringify(data);
             var str ='';
             var srno = 1;
              jQuery.each(data, function(index, item) {
				  
				str += "<tr><td>"+srno+"</td><td>"+item.name+"</td><td>"+item.email_id+"</td><td>"+item.details+"</td><td><a href='Javascript:void(0);' onclick='edit()'>Edit</a> | <a href='Javascript:void(0);' onclick='jsdelete("+item.id+")'>Delete</a></td></tr>";
				srno++;
        });
			$("#resultDisplay").html(str);
          },
          error: function ( xhr ) {
            alert( "error" );
          }
        });
	}
	userList();
	
	function jsdelete(userId) {
		
			$.ajax( { type : 'POST',
			data : {"userId":userId},
          url  : 'http://localhost/codeIgniter-3-api/test/deletUser',              // <=== CALL THE PHP FUNCTION HERE.
          success: function ( data ) {
			userList();
          },
          error: function ( xhr ) {
            alert( "error" );
          }
        });
	}
function js_search_list() {
        document.getElementById("frmSearch").submit();
    }
    $("#clearsearch").click(function(){
        $("#usersearch").val();
        var formData = new FormData($("#usersearch"));
        formData.append("usersearch","");
        document.getElementById("frmSearch").submit();
    });

</script>


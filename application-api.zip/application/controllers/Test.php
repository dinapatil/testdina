<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';


class Test extends REST_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	   public function __construct() {
        parent::__construct();
        $this->load->model('users_model');
    }


	
	public function apiUsersList() {
	
	$this->users_model->allUsersData($searchString='');
		
		$data = array();
		 $this->load->view('apiUsersList',$data);
		 
	}
	public function getUsersList_post() {
		
		$searchString = '';
		$returnUserDataArray = '';
		$returnUserDataArray = $this->users_model->allUsersData($searchString);
		$rowCount = $this->users_model->getUserTotalCount($searchString);
		 $message = [  "userData" => $returnUserDataArray];
		 $this->response( $returnUserDataArray,200); // OK (200) being the HTTP response code
	}
	
	public function deletUser_post() {
		$userId = $this->post('userId');
		
		$returnResult = $this->users_model->userDelete($userId);
		if($returnResult) {
			$msg = "Record deleted successfully";
		} else {
			$msg = "Please try again";
		}
		
		 $message = [  "msg" => $msg];
		 $this->response( $message,200); // OK (200) being the HTTP response code
	}
	
}
